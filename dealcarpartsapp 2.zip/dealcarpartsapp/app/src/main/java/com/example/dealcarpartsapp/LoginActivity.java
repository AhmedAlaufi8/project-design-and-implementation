package com.example.dealcarpartsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    private DBHandler dbHandler;
    EditText log_email, log_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        dbHandler = new DBHandler(this);

        // below line is to add on click listener for our add course button.
        findViewById(R.id.log).setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // below line is to get data from all edit text fields.
                log_email = findViewById(R.id.log_email);
                log_pass = findViewById(R.id.log_pass);

                // validating if the text fields are empty or not.
                if (log_email.getText().toString().isEmpty() || log_pass.getText().toString().isEmpty()) {
                    Toast.makeText(LoginActivity.this, getString(R.string.please_enter_all_the_data), Toast.LENGTH_SHORT).show();
                    return;
                }

                // on below line we are calling a method to add new
                // course to sqlite data and pass all our values to it.
                ArrayList<UserModal> users = dbHandler.read_user();

                for (UserModal user : users) {
                    if (!log_email.getText().toString().equals(user.getEmail()) || !log_pass.getText().toString().equals(user.getPassword())) {
                        Toast.makeText(LoginActivity.this, getString(R.string.data_error), Toast.LENGTH_SHORT).show();
                        return;
                    } else {
                        Intent i = new Intent(LoginActivity.this, HomeActivity.class);
                        i.putExtra("mr", user.getName());
                        startActivity(i);
                    }
                }
            }
        });


        findViewById(R.id.createNewAccount).setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                startActivity(new Intent(LoginActivity.this, RegistrationActivity.class));
            }
        });
    }
}