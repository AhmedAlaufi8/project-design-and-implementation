package com.example.dealcarpartsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.net.URLEncoder;

public class OrderTrackingActivity extends AppCompatActivity {
    EditText name, phone, shop_name, product_name, email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_tracking);

        // below line is to add on click listener for our add course button.
        findViewById(R.id.send).setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // below line is to get data from all edit text fields.
                name = findViewById(R.id.name);
                phone = findViewById(R.id.phone);
                shop_name = findViewById(R.id.shop_name);
                product_name = findViewById(R.id.product_name);
                email = findViewById(R.id.email);

                // validating if the text fields are empty or not.
                if (name.getText().toString().isEmpty() || phone.getText().toString().isEmpty() || shop_name.getText().toString().isEmpty() || product_name.getText().toString().isEmpty() || email.getText().toString().isEmpty()) {
                    Toast.makeText(OrderTrackingActivity.this, getString(R.string.please_enter_all_the_data), Toast.LENGTH_SHORT).show();
                    return;
                }

                PackageManager packageManager = getPackageManager();
                Intent i = new Intent(Intent.ACTION_VIEW);

                try {
                    String url = "https://api.whatsapp.com/send?phone=+96898560516&text=" + URLEncoder.encode("name : " + name.getText().toString() + " | phone : " + phone.getText().toString() + " | shop name : " + shop_name.getText().toString() + " | product name : " + product_name.getText().toString() + " | email : " + email.getText().toString(), "UTF-8");
                    i.setPackage("com.whatsapp");
                    i.setData(Uri.parse(url));
                    if (i.resolveActivity(packageManager) != null) {
                        startActivity(i);
                    } else {
                        Toast.makeText(OrderTrackingActivity.this, "Please install whatsapp first.", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(OrderTrackingActivity.this, "Please install whatsapp first.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}