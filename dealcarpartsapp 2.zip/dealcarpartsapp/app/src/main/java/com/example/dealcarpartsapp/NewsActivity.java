package com.example.dealcarpartsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class NewsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        findViewById(R.id.back_to_home_from_news_page).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.youtube).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/@arabgt")));
            }
        });

        findViewById(R.id.images).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://images.app.goo.gl/rZK8Hm6o4sABn26U6")));
            }
        });

        findViewById(R.id.haraj).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://montada.haraj.com.sa/79493/%D8%A7%D9%84%D9%8A%D9%83%D9%85-%D9%85%D8%AC%D9%85%D9%88%D8%B9%D9%87-%D9%85%D8%AE%D8%AA%D8%A7%D8%B1%D9%87-%D9%85%D9%86-%D9%82%D9%86%D9%88%D8%A7%D8%AA-%D9%8A%D9%88%D8%AA%D9%8A%D9%88%D8%A8-%D8%AA%D9%87%D8%AA%D9%85-%D8%A8%D8%A7%D9%84%D8%B3%D9%8A%D8%A7%D8%B1%D8%A7%D8%AA-/")));
            }
        });
    }
}