package com.example.dealcarpartsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class BuyCarPartsActivity extends AppCompatActivity {
    int cart = 0;

    LinearLayout v1, v2, v3;

    EditText car_agency, type_of_car, car_model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_car_parts);

        findViewById(R.id.back_to_home_from_news_page).setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                finish();
            }
        });

        v1 = findViewById(R.id.view1);
        v2 = findViewById(R.id.view2);
        v3 = findViewById(R.id.view3);

        showView(v1, v2, v3);

        //v1
        {        // below line is to add on click listener for our add course button.
            findViewById(R.id.next).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    // below line is to get data from all edit text fields.
                    car_agency = findViewById(R.id.car_agency);
                    type_of_car = findViewById(R.id.type_of_car);
                    car_model = findViewById(R.id.car_model);

                    // validating if the text fields are empty or not.
                    if (car_agency.getText().toString().isEmpty() || type_of_car.getText().toString().isEmpty() || car_model.getText().toString().isEmpty()) {
                        Toast.makeText(BuyCarPartsActivity.this, getString(R.string.please_enter_all_the_data), Toast.LENGTH_SHORT).show();
                        return;
                    }

                    showView(v2, v1, v3);
                }
            });
        }

        //v2
        {

            findViewById(R.id.maps1).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {
                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/UgmNTKnaepCmmxuK7?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96824464888")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps2).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {
                    showView(v3, v1, v2);
                }
            });
            findViewById(R.id.maps3).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/9mY86WnLNMK9Wrbo7?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96824500500")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps4).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/uhrnurxCWHzSRmfi6?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96824500500")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps5).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/gPUyoLBMLXzt5rDH7?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96871557334")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps6).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/L5ErgjE1TDvRFn5j8?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96898560516")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps7).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/cWKQPkyw6nwJYmv8A?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96824463012")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps8).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/ZC2nyh1eoon6NNBPA?g_st=iw")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps9).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/urgsWknNVnMdnJfG9?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96824450347")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps10).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/DhMfPkzTVZodyNZ37?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96897013231")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps11).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/X1nourqgPoW1WuuJ8?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96824460632")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps12).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/VRfZvJCS11qQo1FF8?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96824454200")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps13).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/2ieCV6oP7YTY2W9u7?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96824460700")));
                        }
                    });
                    dialog.show();
                }
            });
            findViewById(R.id.maps14).setOnClickListener(new android.view.View.OnClickListener() {
                @Override
                public void onClick(android.view.View v) {

                    Dialog dialog = new Dialog(BuyCarPartsActivity.this, R.style.WideDialog);
                    dialog.setContentView(R.layout.map_dialog);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    dialog.findViewById(R.id.map).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.app.goo.gl/HtUQ18cNU8xuBpFp6?g_st=iw")));
                        }
                    });
                    dialog.findViewById(R.id.wa).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/+96879467717")));
                        }
                    });
                    dialog.show();
                }
            });
        }

        //v3
        {
            {
                TextView cartValue = findViewById(R.id.cartValue);

                {
                    TextView count = findViewById(R.id.count);
                    findViewById(R.id.minus).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (16 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }
                {
                    TextView count = findViewById(R.id.count2);
                    findViewById(R.id.minus2).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus2).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart2).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (9 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }
                {
                    TextView count = findViewById(R.id.count3);
                    findViewById(R.id.minus3).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus3).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart3).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (66 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }
                {
                    TextView count = findViewById(R.id.count4);
                    findViewById(R.id.minus4).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus4).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart4).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (32 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }
                {
                    TextView count = findViewById(R.id.count5);
                    findViewById(R.id.minus5).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus5).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart5).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (124 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }
                {
                    TextView count = findViewById(R.id.count6);
                    findViewById(R.id.minus6).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus6).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart6).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (99 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }
                {
                    TextView count = findViewById(R.id.count7);
                    findViewById(R.id.minus7).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus7).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart7).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (6 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }
                {
                    TextView count = findViewById(R.id.count8);
                    findViewById(R.id.minus8).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus8).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart8).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (46 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }
                {
                    TextView count = findViewById(R.id.count9);
                    findViewById(R.id.minus9).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus9).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart9).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (12 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }
                {
                    TextView count = findViewById(R.id.count10);
                    findViewById(R.id.minus10).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus10).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart10).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (39 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }
                {
                    TextView count = findViewById(R.id.count11);
                    findViewById(R.id.minus11).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus11).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart11).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (41 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }
                {
                    TextView count = findViewById(R.id.count12);
                    findViewById(R.id.minus12).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (Integer.parseInt(count.getText().toString()) == 1) return;
                            int i = Integer.parseInt(count.getText().toString()) - 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.plus12).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int i = Integer.parseInt(count.getText().toString()) + 1;
                            count.setText(String.valueOf(i));
                        }
                    });
                    findViewById(R.id.add_to_cart12).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            cart = cart + (60 * Integer.parseInt(count.getText().toString()));
                            cartValue.setText(String.valueOf(cart));
                        }
                    });
                }

                cartValue.setText(String.valueOf(cart));
            }
        }
    }

    public void showView(LinearLayout v, LinearLayout g1, LinearLayout g2) {
        v.setVisibility(View.VISIBLE);
        g1.setVisibility(View.GONE);
        g2.setVisibility(View.GONE);
    }
}