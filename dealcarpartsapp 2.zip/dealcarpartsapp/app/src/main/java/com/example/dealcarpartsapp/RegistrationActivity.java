package com.example.dealcarpartsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrationActivity extends AppCompatActivity {
    private DBHandler dbHandler;
    EditText name, email, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        dbHandler = new DBHandler(this);

        // below line is to add on click listener for our add course button.
        findViewById(R.id.registerAccount).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // below line is to get data from all edit text fields.
                name = findViewById(R.id.name);
                email = findViewById(R.id.email);
                password = findViewById(R.id.password);

                // validating if the text fields are empty or not.
                if (name.getText().toString().isEmpty() || email.getText().toString().isEmpty() || password.getText().toString().isEmpty()) {
                    Toast.makeText(RegistrationActivity.this, getString(R.string.please_enter_all_the_data), Toast.LENGTH_SHORT).show();
                    return;
                }

                // on below line we are calling a method to add new
                // course to sqlite data and pass all our values to it.
                dbHandler.addNewCourse(name.getText().toString(), email.getText().toString(), password.getText().toString());

                // after adding the data we are displaying a toast message.
                Toast.makeText(RegistrationActivity.this, getString(R.string.account_has_been_added_successfully), Toast.LENGTH_SHORT).show();
                startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
            }
        });

        findViewById(R.id.haveAccount).setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistrationActivity.this, LoginActivity.class));
            }
        });
    }
}